import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const fetchSurveillance = async (filters = {}) => {
  const response = await api.get('/api/surveillance', { params: filters });
  return response.data;
};

export const fetchSpecimens = async (filters = {}) => {
  const response = await api.get('/api/specimens', { params: filters });
  return response.data;
};

export const fetchMetrics = async () => {
  const response = await api.get('/api/metrics/live');
  return response.data;
};

export const fetchCompleteness = async (yearMonth: string) => {
  const response = await api.get(`/api/metrics/completeness/${yearMonth}`);
  return response.data;
};

export const fetchCollectors = async () => {
  const response = await api.get('/api/collectors');
  return response.data;
};

export const fetchIncompleteSites = async (yearMonth: string) => {
  const response = await api.get(`/api/metrics/completeness/${yearMonth}/incomplete-sites`);
  return response.data;
};

export default api;
