'use client';

import { useState } from 'react';
import dynamic from 'next/dynamic';
import { useAPI } from '@/hooks/useAPI';
import { fetchMetrics, fetchCompleteness, fetchCollectors } from '@/lib/api';
import type { Metrics, CompletenessData, Collector } from '@/types';

// Dynamic import for Plotly (client-side only)
const Plot = dynamic(() => import('react-plotly.js'), { ssr: false });

const tabs = [
  { id: 0, name: 'Temporal Trends', icon: '📈' },
  { id: 1, name: 'Species Composition', icon: '🦟' },
  { id: 2, name: 'Indoor Resting', icon: '🏠' },
  { id: 3, name: 'Interventions', icon: '🛡️' },
  { id: 4, name: 'Collection Methods', icon: '🔬' },
  { id: 5, name: 'Geographic', icon: '🗺️' },
  { id: 6, name: 'Field Team', icon: '👥' },
  { id: 7, name: 'Completeness', icon: '✅' },
];

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState(0);
  const { data: metrics, loading: metricsLoading, error: metricsError } = useAPI<Metrics>(fetchMetrics);
  const { data: completeness, loading: completenessLoading } = useAPI(() => fetchCompleteness('2025-11'));
  const { data: collectors, loading: collectorsLoading } = useAPI<{ data: Collector[] }>(fetchCollectors);

  if (metricsLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <div className="spinner mb-4"></div>
        <div className="text-xl text-gray-600">Loading dashboard data...</div>
        <div className="text-sm text-gray-500 mt-2">Fetching from backend API</div>
      </div>
    );
  }

  if (metricsError) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-6">
        <h2 className="text-xl font-bold text-red-800 mb-2">Error Loading Data</h2>
        <p className="text-red-600">{metricsError}</p>
        <p className="text-sm text-red-500 mt-2">Make sure backend is running on port 3001</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-sm font-medium text-gray-500">Total Collections</div>
          <div className="text-3xl font-bold text-primary-600 mt-2">
            {metrics?.summary?.totalCollections || 0}
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-sm font-medium text-gray-500">Total Specimens</div>
          <div className="text-3xl font-bold text-green-600 mt-2">
            {metrics?.summary?.totalSpecimens || 0}
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-sm font-medium text-gray-500">Districts</div>
          <div className="text-3xl font-bold text-blue-600 mt-2">
            {metrics?.geographic ? Object.keys(metrics.geographic.districtCounts).length : 0}
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-sm font-medium text-gray-500">Field Collectors</div>
          <div className="text-3xl font-bold text-purple-600 mt-2">
            {collectors?.data?.length || 0}
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="border-b border-gray-200">
          <nav className="flex overflow-x-auto">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-6 py-4 text-sm font-medium whitespace-nowrap flex items-center space-x-2 ${
                  activeTab === tab.id
                    ? 'border-b-2 border-primary-600 text-primary-600 bg-primary-50'
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.name}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        <div className="p-6">
          {activeTab === 0 && <TemporalTrends metrics={metrics} />}
          {activeTab === 1 && <SpeciesComposition metrics={metrics} />}
          {activeTab === 2 && <IndoorResting metrics={metrics} />}
          {activeTab === 3 && <Interventions metrics={metrics} />}
          {activeTab === 4 && <CollectionMethods metrics={metrics} />}
          {activeTab === 5 && <Geographic metrics={metrics} />}
          {activeTab === 6 && <FieldTeam collectors={collectors?.data} loading={collectorsLoading} />}
          {activeTab === 7 && <Completeness data={completeness} loading={completenessLoading} />}
        </div>
      </div>
    </div>
  );
}

// ========== TAB COMPONENTS ==========

function TemporalTrends({ metrics }: { metrics: Metrics | null }) {
  if (!metrics?.temporal) {
    return <div className="text-center text-gray-500 py-12">No temporal data available</div>;
  }

  const months = Object.keys(metrics.temporal.collectionsByMonth).sort();
  const collections = months.map(m => metrics.temporal.collectionsByMonth[m]);
  const specimens = months.map(m => metrics.temporal.specimensByMonth[m] || 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Collections Over Time</h2>
        <div className="text-sm text-gray-500">
          {months.length} months of data
        </div>
      </div>
      
      <Plot
        data={[
          {
            x: months,
            y: collections,
            type: 'scatter',
            mode: 'lines+markers',
            name: 'Collections',
            line: { color: '#0ea5e9', width: 3 },
            marker: { size: 8 },
          },
          {
            x: months,
            y: specimens,
            type: 'scatter',
            mode: 'lines+markers',
            name: 'Specimens',
            line: { color: '#10b981', width: 3 },
            marker: { size: 8 },
            yaxis: 'y2',
          },
        ]}
        layout={{
          title: 'Monthly Surveillance Activity',
          xaxis: { 
            title: 'Month',
            tickangle: -45,
          },
          yaxis: { 
            title: 'Collections',
            side: 'left',
          },
          yaxis2: {
            title: 'Specimens',
            overlaying: 'y',
            side: 'right',
          },
          hovermode: 'x unified',
          showlegend: true,
          legend: { x: 0.1, y: 1.1, orientation: 'h' },
        }}
        config={{ responsive: true, displayModeBar: true }}
        className="w-full"
        style={{ width: '100%', height: '500px' }}
      />
    </div>
  );
}

function SpeciesComposition({ metrics }: { metrics: Metrics | null }) {
  if (!metrics?.species) {
    return <div className="text-center text-gray-500 py-12">No species data available</div>;
  }

  const species = Object.keys(metrics.species.speciesCounts);
  const counts = Object.values(metrics.species.speciesCounts);
  
  const anopheles = metrics.species.anophelesBreakdown 
    ? Object.keys(metrics.species.anophelesBreakdown)
    : [];
  const anophelesCounts = metrics.species.anophelesBreakdown
    ? Object.values(metrics.species.anophelesBreakdown)
    : [];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Species Distribution</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pie Chart */}
        <div className="bg-gray-50 rounded-lg p-4">
          <Plot
            data={[
              {
                labels: species,
                values: counts,
                type: 'pie',
                hole: 0.4,
                marker: {
                  colors: ['#0ea5e9', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'],
                },
              },
            ]}
            layout={{
              title: 'Species Composition',
              showlegend: true,
              legend: { orientation: 'v' },
            }}
            config={{ responsive: true }}
            style={{ width: '100%', height: '400px' }}
          />
        </div>

        {/* Bar Chart */}
        <div className="bg-gray-50 rounded-lg p-4">
          <Plot
            data={[
              {
                x: species,
                y: counts,
                type: 'bar',
                marker: { color: '#0ea5e9' },
              },
            ]}
            layout={{
              title: 'Species Counts',
              xaxis: { title: 'Species', tickangle: -45 },
              yaxis: { title: 'Count' },
            }}
            config={{ responsive: true }}
            style={{ width: '100%', height: '400px' }}
          />
        </div>
      </div>

      {/* Anopheles Breakdown */}
      {anopheles.length > 0 && (
        <div className="bg-gray-50 rounded-lg p-4">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Anopheles Species Breakdown</h3>
          <Plot
            data={[
              {
                x: anopheles,
                y: anophelesCounts,
                type: 'bar',
                marker: { color: '#10b981' },
              },
            ]}
            layout={{
              title: 'Anopheles Species Distribution',
              xaxis: { title: 'Species', tickangle: -45 },
              yaxis: { title: 'Count' },
            }}
            config={{ responsive: true }}
            style={{ width: '100%', height: '400px' }}
          />
        </div>
      )}
    </div>
  );
}

function IndoorResting({ metrics }: { metrics: Metrics | null }) {
  return (
    <div className="text-center text-gray-500 py-12">
      <div className="text-6xl mb-4">🏠</div>
      <p className="text-lg font-medium">Indoor Resting Density</p>
      <p className="text-sm mt-2">PSC collection analysis - Coming soon</p>
    </div>
  );
}

function Interventions({ metrics }: { metrics: Metrics | null }) {
  return (
    <div className="text-center text-gray-500 py-12">
      <div className="text-6xl mb-4">🛡️</div>
      <p className="text-lg font-medium">Interventions</p>
      <p className="text-sm mt-2">LLIN & IRS coverage analysis - Coming soon</p>
    </div>
  );
}

function CollectionMethods({ metrics }: { metrics: Metrics | null }) {
  if (!metrics?.methods) {
    return <div className="text-center text-gray-500 py-12">No collection method data available</div>;
  }

  const methods = Object.keys(metrics.methods.methodCounts);
  const counts = Object.values(metrics.methods.methodCounts);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Collection Methods</h2>
      <Plot
        data={[
          {
            x: methods,
            y: counts,
            type: 'bar',
            marker: { color: '#8b5cf6' },
          },
        ]}
        layout={{
          title: 'Specimens by Collection Method',
          xaxis: { title: 'Method', tickangle: -45 },
          yaxis: { title: 'Count' },
        }}
        config={{ responsive: true }}
        style={{ width: '100%', height: '500px' }}
      />
    </div>
  );
}

function Geographic({ metrics }: { metrics: Metrics | null }) {
  if (!metrics?.geographic) {
    return <div className="text-center text-gray-500 py-12">No geographic data available</div>;
  }

  const districts = Object.keys(metrics.geographic.districtCounts);
  const counts = Object.values(metrics.geographic.districtCounts);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Geographic Distribution</h2>
      <Plot
        data={[
          {
            x: districts,
            y: counts,
            type: 'bar',
            marker: { color: '#ec4899' },
          },
        ]}
        layout={{
          title: 'Collections by District',
          xaxis: { title: 'District', tickangle: -45 },
          yaxis: { title: 'Count' },
        }}
        config={{ responsive: true }}
        style={{ width: '100%', height: '500px' }}
      />
    </div>
  );
}

function FieldTeam({ collectors, loading }: { collectors: Collector[] | undefined; loading: boolean }) {
  if (loading) {
    return <div className="flex justify-center py-12"><div className="spinner"></div></div>;
  }

  if (!collectors || collectors.length === 0) {
    return <div className="text-center text-gray-500 py-12">No collector data available</div>;
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Field Team Activity</h2>
      
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Collector
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                District
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Submissions
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Activity Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Last Submission
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {collectors.slice(0, 20).map((collector, i) => (
              <tr key={i}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {collector.collector_name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {collector.district}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {collector.total_submissions}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    collector.activity_status === 'Active' ? 'bg-green-100 text-green-800' :
                    collector.activity_status === 'Inactive' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {collector.activity_status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {collector.last_submission ? new Date(collector.last_submission).toLocaleDateString() : 'N/A'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Completeness({ data, loading }: { data: any; loading: boolean }) {
  if (loading) {
    return <div className="flex justify-center py-12"><div className="spinner"></div></div>;
  }

  if (!data?.data || data.data.length === 0) {
    return <div className="text-center text-gray-500 py-12">No completeness data available</div>;
  }

  const districts: CompletenessData[] = data.data;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Data Completeness Dashboard</h2>
        <div className="text-sm text-gray-500">
          Month: November 2025
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                District
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Total Houses
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                With Data
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Complete
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Submission Rate
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Completeness
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {districts.map((d, i) => (
              <tr key={i} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {d.district}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {d.totalHouses}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {d.housesWithData}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {d.housesWithCompleteData}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    d.submissionRate >= 80 ? 'bg-green-100 text-green-800' :
                    d.submissionRate >= 50 ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {d.submissionRate.toFixed(1)}%
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    d.completenessRate >= 80 ? 'bg-green-100 text-green-800' :
                    d.completenessRate >= 50 ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {d.completenessRate.toFixed(1)}%
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
